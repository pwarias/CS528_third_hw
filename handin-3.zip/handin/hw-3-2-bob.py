'''
 Will act as the server, and wait to receive the encrypted matrix from Alice
 before performing computations on it and returning it
'''

from phe import paillier
from ast import literal_eval
import json, socket, pickle, struct

HOST = '127.0.0.1'
PORT = 65431
B = [[5, 6, 10, 1],
     [8, 1, 12, 13],
     [7, 2, 1, 15],
     [5, 6, 3, 10],
     [13, 20, 1, 4],
     [40, 33, 27, 4],
     [17, 8, 26, 43],
     [35, 30, 19, 38]
]

def recv_data(conn):
    size_in_4_bytes = conn.recv(4)
    size = struct.unpack('I', size_in_4_bytes)
    size = size[0]
    print("will receive ", size, " bytes")
    un_enc_data = conn.recv(size)
    data = literal_eval(un_enc_data.decode("utf-8"))
    return data

def send_data(conn, data):
    size = len(data)
    size_in_4_bytes = struct.pack('I', size)
    print("sending ...", size, " bytes")
    conn.send(size_in_4_bytes)
    conn.sendall(bytes(data, encoding="utf8"))

def decode_serialized_paillier(received_dict):
    pk = received_dict['public_key']
    public_key_rec = paillier.PaillierPublicKey(n=int(pk['n']))
    enc_nums_rec = [
        [paillier.EncryptedNumber(public_key_rec, int(x[0]), int(x[1]))
            for x in received_dict['values'][j]] for j in range(len(received_dict['values']))
        ]   
    return enc_nums_rec 

def package_matrix(matrix, public_key):
    print("packaging matrix ...")
    enc_dict = {}
    enc_dict['public_key'] = {'n': public_key['n']}
    enc_dict['values'] = [[
        (str(x.ciphertext()), x.exponent) for x in matrix[j]] for j in range(len(matrix))
    ]
    return enc_dict

# A X B (5x8 and 8x4 matrices = 5x4 result)
res = [[0 for x in range(4)] for y in range(5)]

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.bind((HOST, PORT))
    s.listen()
    conn, addr = s.accept()
    with conn:
        print("connected by ", addr)
        received_dict = recv_data(conn)
        if not received_dict:
            print("nothing received")
        enc_nums_rec = decode_serialized_paillier(received_dict)
        for i in range(len(enc_nums_rec)):
            for j in range(len(B[0])):
                for k in range(len(enc_nums_rec[0])):
                    res[i][j] += enc_nums_rec[i][k] * B[k][j]
        result = package_matrix(res, received_dict['public_key'])
        send_data(conn, json.dumps(result))
        