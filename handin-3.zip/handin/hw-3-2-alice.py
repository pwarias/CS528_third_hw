'''
Will act as the client for the sockets, Alice generates the encrypted matrix and sends
it over to Bob so he can perform multiplication on it. 
'''

from phe import paillier
from ast import literal_eval
import json, socket, pickle, struct, time

HOST = '127.0.0.1'
PORT = 65431
A = [[22, 28, 17, 38, 37, 39, 30, 14],
     [19, 48, 40, 38, 29, 38, 22, 34],
     [22, 16, 6, 2, 25, 21, 39, 38],
     [38, 42, 34, 28 ,35, 49, 5, 40],
     [48, 5, 39, 22, 40, 37, 29, 27]
]
def send_data(conn, data):
    size = len(data)
    size_in_4_bytes = struct.pack('I', size)
    print("sending size ...", size, " bytes")
    conn.send(size_in_4_bytes)
    time.sleep(2)
    conn.sendall(bytes(data, encoding="utf8"))

def recv_data(conn):
    size_in_4_bytes = conn.recv(4)
    size = struct.unpack('I', size_in_4_bytes)
    size = size[0]
    print("will receive ", size, " bytes")
    un_enc_data = conn.recv(size)
    data = literal_eval(un_enc_data.decode("utf-8"))
    return data

def package_matrix(matrix, public_key):
    print("packaging matrix ...")
    enc_dict = {}
    enc_dict['public_key'] = {'n': public_key.n}
    enc = [[public_key.encrypt(i) for i in matrix[j]] for j in range(len(matrix))]
    enc_dict['values'] = [[
        (str(x.ciphertext()), x.exponent) for x in enc[j]] for j in range(len(matrix))
    ]
    return enc_dict

def decode_serialized_paillier(received_dict):
    print("decoding message ...")
    pk = received_dict['public_key']
    public_key_rec = paillier.PaillierPublicKey(n=int(pk['n']))
    enc_nums_rec = [
        [paillier.EncryptedNumber(public_key_rec, int(x[0]), int(x[1]))
            for x in j] for j in received_dict['values']
        ]
    return enc_nums_rec

def test():
    for row in A:
        print(row)
    public_key, private_key = paillier.generate_paillier_keypair()
    enc_dict = package_matrix(A, public_key)
    test = decode_serialized_paillier(enc_dict)
    res = [[private_key.decrypt(i) for i in test[j]] for j in range(len(test))]
    for row in res:
        print(row)
with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.connect((HOST, PORT))
    public_key, private_key = paillier.generate_paillier_keypair(None, 1024)
    enc_dict = package_matrix(A, public_key)
    serialized = json.dumps(enc_dict)
    send_data(s, serialized)

    # After Bob's computation
    data = recv_data(s)
    enc_res = decode_serialized_paillier(data)
    print("CIPHERTEXT BEFORE DECRYPTION")
    print([[x.ciphertext() for x in y] for y in enc_res])    
    print("-" *80)
    res = [[private_key.decrypt(i) for i in enc_res[j]] for j in range(len(enc_res))]
print("received ", repr(res))